function Timely_update(){
    let dt = new Date();
    let time = (dt.getMonth()+1)+'-'+dt.getDate()+' '+dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
    document.getElementById('update_time').innerText = '更新时间: '+ time;
}

////Average efficiency chart
function machine_status(data){

    let avg_efficiency = 0;
    let running = data.filter(d=>d['State']=='0' ).length;
    let powerOff = data.filter(d=>d['State']=='1' ).length;
    let offLine = data.filter(d=>d['State']=='56' );
    let notSycn = data.filter(d=>d['State']=='65535' );
    let stop = data.filter(d=>d['State']!='1' &&d['State']!='56' &&d['State']!='65535' &&d['State']!='0').length;

    if (document.getElementById('avg_efficiency') != null) {
        echarts.dispose(document.getElementById('avg_efficiency'))
    }
    let myChart = echarts.init(document.getElementById('avg_efficiency'));

    //pie data
    let filterdata = data.filter(d=>d['State']!='1' &&d['State']!='56' &&d['State']!='65535' )
    let y_1 = filterdata.map(d=>parseFloat(d['WorkEfficiency']))
    let average = (array) => array.reduce((a, b) => a + b) / array.length;
    avg_efficiency = average(y_1).toFixed(2)

    let colorPalette = [ '#14ca75','#4a8df6', '#dea33d','#f36069'];
    let pie_data = [0,0,0,0]
    for(let i in y_1){
        if(y_1[i]<80){
            pie_data[3]+=1;
        }else if(y_1[i]>=80 && y_1[i]<90){
            pie_data[2]+=1;
        }else if(y_1[i]>=90 && y_1[i]<95){
            pie_data[1]+=1;
        }else{
            pie_data[0]+=1;
        }
    }

    let  option = {

        tooltip: {
            trigger: 'item',
            transitionDuration:0,
            formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        legend: {
            itemWidth: 8,
            itemHeight: 8,
            left: 'center',
            top: "1%",
            data: ['95%~100%', '90%~95%', '80%~90%', '<80%'],
            textStyle:{
                fontSize : 12
            }
        },
        series: [
            {
                name:'work efficiency',
                type: 'pie',
                radius: [30, 55],
                center: ['57%', '57%'],
                roseType: 'area',
                data: [
                    {value: pie_data[0], name: '95%~100%'},
                    {value: pie_data[1], name: '90%~95%'},
                    {value: pie_data[2], name: '80%~90%'},
                    {value: pie_data[3], name: '<80%'}
                ],
                label:{            //饼图图形上的文本标签
                    normal:{
                        show:true,
                        position:'outside', //标签的位置
                        textStyle : {
                            fontSize : 13    //文字的字体大小
                        },
                        formatter:'{c} ({d}%)'


                    }
                },
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                },
                color: colorPalette,
                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b} : {c} ({d}%)'
                },
                labelLine: {    //引导线设置
                    normal: {
                        show: true,   //引导线显示
                        length:0.001
                    }
                },
            }
        ]
    };


    myChart.clear();
    myChart.setOption(option);
    window.onresize = function(){
        myChart.resize();
    }

    document.getElementById('sum_avgE').innerText = avg_efficiency+'%';
    document.getElementById('sum_running').innerText = running;
    document.getElementById('sum_stop').innerText = stop;
    document.getElementById('sum_poweroff').innerText = powerOff;
    offLine = offLine.map(d=>'#'+d['MachCode'])
    document.getElementById('sum_offLine').innerText = offLine.length+' ('+offLine.toString()+')';
    notSycn = notSycn.map(d=>'#'+d['MachCode'])
    document.getElementById('sum_noSyncr').innerText = notSycn.length+' ('+notSycn.toString()+')';

}

///summary_realtime_error_chart
function realtime_error_chart(error_data){
    let colorPlate = [ '#3b8ade', '#f1aa1d','#DF3B45','#3db005', '#9B59B6', '#2471A3','#138D75','#D68910','#34495E','#FF5733','#00b04f'];
    let error_code = [...new Set(error_data.map(d=>d['StopCode']))];
    let data_value = []
    let error_dict = {}
    for(let i in error_code){
        let error_sublist = error_data.filter(d=>d['StopCode']==error_code[i])
        error_dict[error_code[i]] = {count:error_sublist.length,description:error_sublist[0]['description'],code:error_code[i]}
    }

    let top_10_error =  Object.keys(error_dict).sort(function(a,b){
        return error_dict[b]['count']-error_dict[a]['count'];
    });
    top_10_error = top_10_error.slice(0,10)
    top_10_error.forEach(function(d){
        data_value.push({value:error_dict[d]['count'],name:error_dict[d]['code']})
    })


    if (document.getElementById('error_summary') != null) {
        echarts.dispose(document.getElementById('error_summary'))
    }
    let myChart = echarts.init(document.getElementById('error_summary'));
    let option = {

        tooltip: {
            trigger: 'item',
            showDelay: 20,
            hideDelay: 20,
            transitionDuration:0,

            formatter: function(data){
                return error_dict[data['name']]['description']+'<br/>'+'Counts：'+data.value+' ('+data.percent+'%)'
            }
        },
        legend: {
            show:false,
        },
        grid: {
            top:'2%',
            left: '0%',
            right: '14%',
            bottom: '3%'
        },

        label:{
            textStyle:{
                fontWeight : 'normal',
                fontSize : 26
            }

        },
        series: [
            {
                type: 'pie',
                radius: '55%',
                center: ['50%', '60%'],
                data: data_value,
                color:colorPlate,
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };
    myChart.clear();
    myChart.setOption(option);
    window.onresize = function(){
        myChart.resize();
    }

    document.getElementById('error_happening').innerText="";
    document.getElementById('error_total').innerText = error_data.length;
    let machine_error_top = [...new Set(error_data.map(d=>d['MachCode']))];
    let machine_error_top_dict = {}
    for(let i in machine_error_top){
        machine_error_top_dict[machine_error_top[i]] = (error_data.filter(d=>d['MachCode']==machine_error_top[i])).length
    }
    let machine_error_top_5 = Object.keys(machine_error_top_dict).sort(function(a,b){
        return machine_error_top_dict[b]-machine_error_top_dict[a];
    });
    document.getElementById('error_5_machines').innerText = ((machine_error_top_5.slice(0,5)).map(d=>'#'+d)).toString()

}

///summary style production table
function style_production_table(product_table){

    let styleList = [... new Set(product_table.map(d=>d['StyleCode']))]
    let content_html = "" ;
    for(let i in styleList) {
        let style_data = product_table.filter(item => item['StyleCode'] == styleList[i])
        let machines = [... new Set(style_data.map(d=>d['MachCode']))]
        let amounts = 0
        style_data.forEach(function (d) {
            amounts += d['ShiftPieces']
        })
        if(amounts<0.5){
            continue
        }
        let content = '<tr><td>' + styleList[i] + '</td><td>' + (parseFloat(amounts) / 2).toFixed(1) + '</td><td>' + machines.toString()+ '\n';
        content_html += content
    }
    document.getElementById("real_style_table_body").innerHTML =content_html;
}