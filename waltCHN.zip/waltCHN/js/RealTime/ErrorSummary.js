



function unfixed_error(error_data){
    let fixed = [];
    let unfixed = [];
    for(let i in error_data){
        if(error_data[i]['DateEndStop']){
            fixed.push(error_data[i])
        }else{
            if(error_data[i]['StopCode']!=99992){
                unfixed.push(error_data[i])
            }
        }
    }

    $("#unfixed_body").empty();
    let content_html = '';
    let new_error_data = unfixed.filter(item=>item['StopCode']!=99992)
    let filter_error_data =[]
    for (let i in unfixed){
        if(unfixed[i]['StopCode']==99992){
            continue;
        }else{
            filter_error_data.push(unfixed[i])
        }
    }
    console.log(unfixed)
    document.getElementById('error_happening').innerText = unfixed.length;

    for(let i = 0;i<filter_error_data.length;i++){
        let date = filter_error_data[i]['DateRec'].slice(10, filter_error_data[i]['DateRec'].length)
        let content ='<tr><td>'+'#'+filter_error_data[i]['MachCode']+'</td><td>' + filter_error_data[i]['StopCode'] + '</td><td>' + date+'</td><td>' + filter_error_data[i]['description']+'</td></tr>';
        content_html += content + '\n';
    }
    document.getElementById("unfixed_body").innerHTML =content_html;

}


function error_summary_stopCode(error_Data){

    let error_list = [...new Set(error_Data.map(d=>d['StopCode']))]
    let error_dict = {}
    for(let i in error_list){
        error_dict[error_list[i]] = error_Data.filter(d=>d['StopCode']==error_list[i]).length;
    }
    let error_top_10 = Object.keys(error_dict).sort(function(a,b){
        return error_dict[b]-error_dict[a];
    });
    error_top_10 = error_top_10.slice(0,10)
    let y_array = []
    error_top_10.forEach(function(d){
        y_array.push(error_dict[d])
    })

    if (document.getElementById('error_summary_stopCode') != null) {
        echarts.dispose(document.getElementById('error_summary_stopCode'))
    }
    let myChart = echarts.init(document.getElementById('error_summary_stopCode'));


    let option = {
        title: {
            text: '前10故障分布',
            top:'5%',
            left: 'center',
            textStyle:{//标题内容的样式
                color:'dodgerblue',

            },
        },

        tooltip: {
            trigger: 'axis',
            showDelay: 20,
            hideDelay: 20,
            transitionDuration:0,
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            },
            formatter: function (params) {
                console.log(params)
                let obj = error_Data.filter(d=>d['StopCode']==params[0]['name'])
                return obj[0]['description']
            }
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            top:'15%',
            containLabel: true
        },
        xAxis: {
            type: 'value',
            splitLine: {
                lineStyle: {
                    color:['#22cab7']
                }
            },
            axisLine:{
                lineStyle:{
                    color:'#22cab7',
                    width:2,
                }
            }


        },
        yAxis: {
            type: 'category',
            data: error_top_10,
            axisLabel: {
                show: true, //默认为true，设为false后下面都没有意义了
                interval: 0, //此处关键， 设置文本标签全部显示
                interval: 0, //此处关键， 设置文本标签全部显示
                interval: 0, //此处关键， 设置文本标签全部显示
            },
            nameTextStyle:{
                color:['#be7012']
            },
            axisLine: {
                lineStyle:{
                    color:'#ebf8ac',
                    width:2
                },

            }
        },
        series: [
            {
                name: 'Error Fixed',
                type: 'bar',
                stack: '总量',
                label: {
                    show: true,
                    position: 'insideRight'
                },
                data: y_array,
                itemStyle: {
                    normal: {
                        barBorderRadius: 5,
                        color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [{
                            offset: 0,
                            color: "#e965dc"
                        },
                            {
                                offset: 1,
                                color: "#edc2ee"
                            }
                        ])
                    }
                },
                formatter: function(params) {
                    if (params.value > 0) {
                        return params.value;
                    } else {
                        return ' ';
                    }
                }

            },

        ]
    };
    myChart.clear();

    myChart.setOption(option)
    window.onresize = function(){
        myChart.resize();
    }

}

function error_summary_machine(error_data){

    let machine = [...new Set(error_data.map(d=>d['MachCode']))]
    let machine_dict = {}
    for(let i in machine){
        machine_dict[machine[i]] = error_data.filter(d=>d['MachCode']==machine[i]).length;
    }
    let machine_top_10 = Object.keys(machine_dict).sort(function(a,b){
        return machine_dict[b]-machine_dict[a];
    });
    machine_top_10 = machine_top_10.slice(0,10)
    let y_array = []
    machine_top_10.forEach(function(d){
        y_array.push(machine_dict[d]);
        return '#'+d
    })

    machine_top_10 = machine_top_10.map(d=>'#'+d)

    if (document.getElementById('error_summary_machines') != null) {
        echarts.dispose(document.getElementById('error_summary_machines'))
    }
    let myChart = echarts.init(document.getElementById('error_summary_machines'));


    let option = {
        title: {
            left: 'center',
            text: '前10故障率的机器分布',
            textStyle:{//标题内容的样式
                color:'dodgerblue',

            },
        },
        tooltip: {
            trigger: 'axis',
            showDelay: 20,
            hideDelay: 20,
            transitionDuration:0,
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
        },

        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: [
            {
                type: 'category',
                data: machine_top_10,
                axisLabel: {
                    show: true, //默认为true，设为false后下面都没有意义了
                    interval: 0, //此处关键， 设置文本标签全部显示
                },

                axisLine:{
                    lineStyle:{
                        color:'#22cab7',
                        width:2,
                    }
                }
            }
        ],
        yAxis: [
            {
                type: 'value',

                nameTextStyle:{
                    color:['#be7012']
                },
                axisLine: {
                    lineStyle:{
                        color:'#ebf8ac',
                        width:2
                    },

                }


            }
        ],
        series: [

            {
                type: 'bar',
                stack: 'total',
                label: {
                    show: true,
                    position: 'top',
                    textStyle:{
                        color:"white"
                    }
                },
                data: y_array,
                itemStyle: {
                    normal: {
                        barBorderRadius: 5,
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: "#8ac47d"
                        },
                            {
                                offset: 1,
                                color: "#bdd7ac"
                            }
                        ])
                    }
                },

            }


        ]
    };
    myChart.clear();

    myChart.setOption(option);
    myChart.on('click', function (params) {

        let select_data = fixedData.filter(item=>item['MachCode']==params['name'].slice(1))
        for(let i in errorData){
            if (errorData[i]['MachCode']==params['name'].slice(1)){
                select_data.push(errorData[i]);
            }
        }
        let select_error_data = {}
        for(let m in select_data){
            if (select_data[m]['StopCode'] in select_error_data){
                select_error_data[select_data[m]['StopCode']]['count']+=1;
            }else{
                select_error_data[select_data[m]['StopCode']] = {'stopCode':select_data[m]['StopCode'],'description':select_data[m]['description'],'count':1}
            }
        }
        let res="";
        let res_down = Object.keys(select_error_data).sort(function(a,b){
            return select_error_data[b]['count']-select_error_data[a]['count'];
        });
        for(let i in res_down){
            let obj = select_error_data[res_down[i]];
            res += 'count:'+obj['count']+"--"+obj['description']+'\n'
        }
        alert(res)
    })
    window.onresize = function(){
        myChart.resize();
    }
}
