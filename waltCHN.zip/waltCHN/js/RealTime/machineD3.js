function realTime_machine_d3(raw_data) {

    let machine_data = raw_data['machine']
    let w_efficiency = [];
    let t_efficiency = [];
    let real_piece = [];
    let style = []
    let machine_id = [];

    let page_width = document.getElementById("center_area").offsetWidth;

    let margin = {top: 0, right: 28, bottom: 0, left: 28},
        width = page_width - margin.left - margin.right,
        height = 340 - margin.top - margin.bottom;


    let data = machine_data;

    d3.select("svg").remove();
    let svg_container = d3.select("#machine_d3")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform",
            "translate(" + margin.left + "," + margin.top + ")");
    let images = svg_container.selectAll("image")
        .data(data)
        .enter()
        .append('g')

    images.append('image')
        .attr('xlink:href', function (d) {
            if (d['State']==1){
                return 'image/off2.png'
            }else if(d['State']==0){

                return 'image/run_n.png'
            }else if(d['State']==56 ){
                return 'image/offline.jpg'
            }else if(d['State']==65535){
                return 'image/not_sync.png'
            }
            else{
                return 'image/stop.PNG'
            }
        })
        .attr("x", function (d,i) { return (i%10)*80+50 })
        .attr("y", function(d,i){
            if(i<10){
                return 20
            }else if(i>=10 && i<20){
                return 100
            }else if(i>=20 && i<30){
                return 180
            }else{
                return 260
            }
        })
        .attr('width',40)
        .attr('height',35)
        .on("mouseover", function(d,i) {
            d3.select(this)
                .attr('width',50)
                .attr('height',45)
                .style("cursor", "pointer");
        })
        .on("mouseout", function(d,i) {
            d3.select(this)
                .attr('width',40)
                .attr('height',35)
                .style("cursor", "default");
        })
        .on('click',function(d,i){
            let product = raw_data['product']

            let error = raw_data['error'].filter(item=>item['MachCode']==d['MachCode'])
            real_machine_error_chart(error)

            let cycleList = product.filter(item=>item['MachCode']==d['MachCode'])
            cycleList = [...new Set(cycleList.map(d=>d['Cycle']))]
            document.getElementById('real_machine_id').innerText=d['MachCode'];
            let state = ''
            if(d['State']=='0'){
                state = 'RUNNING'
            }else if(d['State']=='1'){
                state = 'POWER OFF'
            }else if(d['State']=='56'){
                state = 'OFF LINE'
            }else if(d['State']=='65535'){
                state = 'NOT SYNCR'
            }else{
                state = 'STOPPING'
            }
            document.getElementById('real_machine_state').innerText =state
            document.getElementById('real_machine_we').innerText =d['WorkEfficiency']+'%'
            document.getElementById('real_machine_te').innerText =((parseInt(d['TimeOn'])/(parseInt(d['TimeOn'])+parseInt(d['TimeOff']))).toFixed(2))*100+'%'
            document.getElementById('real_machine_error').innerText =error.length;
            document.getElementById('real_machine_lastSC').innerText =d['LastStopCode']
            document.getElementById('real_machine_styleCode').innerText =d['StyleCode']
            document.getElementById('real_machine_pieces').innerText =d['ShiftPieces']
            document.getElementById('real_machine_cycleList').innerText =cycleList.toString() ;
            document.getElementById('real_machine_frequency_cycle').innerText =d['LastCycle']
        })

    images.append('text')
        .text(function(d){
            return '#'+d['MachCode']
        })
        .attr("x", function (d,i) { return (i%10)*80+58 })
        .attr("y", function(d,i){
            if(i<10){
                return 20+50
            }else if(i>=10 && i<20){
                return 100+50
            }else if(i>=20 && i<30){
                return 180+50
            }else{
                return 260+50
            }
        })
        .attr('font-size',18)
        .style('fill','#22cab7')


}

///efficiency
function realTime_machine_efficiency(machine_data){
    let machine_set = [...new Set(machine_data.map(d=>d['MachCode']))]
    let x_array = []
    let y_array = []
    let y_array_time_effciency = []

    for(let i in machine_set){
        let obj = machine_data.filter(d=>d['MachCode']==machine_set[i])

        let time_efficiency = parseInt(obj[0]['TimeOn'])/((parseInt(obj[0]['TimeOn'])+parseInt(obj[0]['TimeOff'])))
        if(obj[0]['WorkEfficiency']>0 ||time_efficiency){
            x_array.push(machine_set[i]);
            y_array.push(obj[0]['WorkEfficiency'])
            y_array_time_effciency.push((time_efficiency.toFixed(2))*100)
        }

    }

    if (document.getElementById('realTime_machine_efficiency') != null) {
        echarts.dispose(document.getElementById('realTime_machine_efficiency'))
    }

    let myChart = echarts.init(document.getElementById('realTime_machine_efficiency'));

    let option = {
        legend: {
            data: ['生产效率(%)','开机效率(%)'],
            top:"1%",
            left:'1%',
            textStyle:{//图例文字的样式
                color:'dodgerblue',
                fontSize:16
            }
        },

        grid: {
            top:'16%',
            left: '5%',
            right: '6%',
            bottom: '12%'
        },
        tooltip: {
            trigger: 'axis',
            showDelay: 20,
            hideDelay: 20,
            transitionDuration:0,
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            },
        },
        xAxis: {
            type: 'category',
            name: '[ID:#]',
            data:x_array.map(d=>d),
            axisLabel: {
                interval: 0,
                show: true, //默认为true，设为false后下面都没有意义了
            },
            axisLine:{
                lineStyle:{
                    color:'#22cab7',
                    width:2,
                }
            }
        },
        yAxis: [
            {
                type: 'value',
                splitLine: {
                    show:false,
                    lineStyle: {
                        color:['#be7012']
                    }
                },
                nameTextStyle:{
                    color:['#7e25d7']
                },
                axisLine: {
                    lineStyle:{
                        color:'#e55816',
                        width:2
                    },

                }
            },

        ],
        // Declare several bar series, each will be mapped
        // to a column of dataset.source by default.
        series: [
            {
                name: '生产效率(%)',
                type: 'bar',
                data: y_array,
                markLine: {
                    data: [
                        {
                            type: 'average',
                            name: '平均值',
                        },

                    ],
                    itemStyle:{
                        color:'orange'
                    }
                },
                itemStyle: {
                    normal: {
                        barBorderRadius: 2,
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: "#52d919"
                        },
                            {
                                offset: 1,
                                color: "#bcf5ad"
                            }
                        ])
                    }
                },
            },
            {
                name: '开机效率(%)',
                type: 'bar',
                data: y_array_time_effciency,
                itemStyle: {
                    normal: {
                        barBorderRadius: 2,
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: "#da3fe5"
                        },
                            {
                                offset: 1,
                                color: "#d6b0ee"
                            }
                        ])
                    }
                },
            }
        ]
    };
    myChart.clear();
    myChart.setOption(option);
    window.onresize = function(){
        myChart.resize();
    }
}

//production
function realTime_machine_production(machine_data){

    let data = machine_data.filter(d=>(d['State']!=1||d['State']!=56 ||d['State']!=65535) && d['ShiftPieces']>=0.5)
    let machine_set = [...new Set(data.map(d=>d['MachCode']))];
    let style_list = [...new Set(data.map(d=>d['StyleCode']))];

    //style code dropdown menu
    $("#real_style_menu").empty()
    let real_style_list = style_list.map(item=>item.toUpperCase())
    real_style_list = [...new Set(real_style_list)];
    $("#real_style_menu").append('<li class="dropdown-item" ><a href="#">All Styles</a></li>');
    for(let m in real_style_list){
        if(real_style_list[m]){
            $("#real_style_menu").append('<li class="dropdown-item"><a href="#">'+real_style_list[m]+'</a></li>');
        }
    }


    let seriesList = [];
    let total = 0;
    for (let i=0; i<style_list.length;i++)
    {
        if(style_list[i]){
            let init_data = []
            for(let j in machine_set){
                let obj = data.filter(d=>d['MachCode']==machine_set[j]);
                if(obj[0]['StyleCode']==style_list[i]){
                    total+=obj[0]['ShiftPieces']
                    init_data.push(obj[0]['ShiftPieces'])
                }else{
                    init_data.push(0)
                }
            }
            seriesList.push(
                {
                    name:style_list[i],
                    type:'bar',
                    stack: 'area',
                    label: {
                        show: true,
                        position: 'insideTop',
                        formatter: function(params) {
                            if (params.value > 0) {
                                return params.value;
                            } else {
                                return ' ';
                            }
                        },
                    },
                    symbol: 'none',
                    data: init_data
                }
            );//end-push
        }

    } //end-for-loop
    if (document.getElementById('realTime_machine_production') != null) {
        echarts.dispose(document.getElementById('realTime_machine_production'))
    }
    let myChart = echarts.init(document.getElementById('realTime_machine_production'));
    let option = {
        title: {
            left: 'left',
            text: '机器生产记录 (总计只数:'+total+')',
            textStyle:{//标题内容的样式
                color:'#FF5733',

            },
        },
        grid: {
            top:'16%',
            left: '5%',
            right: '6%',
            bottom: '12%'
        },
        legend: {
            data:style_list,
            top:"12%",
            bottom: '10%',
            textStyle:{//标题内容的样式
                color:'dodgerblue',

            },
        },
        tooltip: {
            trigger: 'axis',
            showDelay: 20,
            hideDelay: 20,
            transitionDuration:0,
            axisPointer: {
                type: 'shadow'
            }
        },
        xAxis: {
            type: 'category',
            name:'[ID:#]',
            data:machine_set,
            axisLabel: {
                show: true, //默认为true，设为false后下面都没有意义了
                interval: 0, //此处关键， 设置文本标签全部显示
            },
            axisLine:{
                lineStyle:{
                    color:'#22cab7',
                    width:2,
                }
            }
        },
        yAxis: [
            {
                show:false,
                type: 'value',
                nameTextStyle:{
                    show:false,
                    color:['#ebf8ac']
                },
                axisLine: {
                    show:false,
                    lineStyle:{
                        color:'#ebf8ac',
                        width:2
                    }},
                splitLine: {
                    show:false
                }
            }
        ],
        // Declare several bar series, each will be mapped
        // to a column of dataset.source by default.
        series: seriesList
    };
    console.log(seriesList)

    myChart.clear();
    myChart.setOption(option);
    window.onresize = function(){
        myChart.resize();
    }


}

function production_error(machine_data,flag){
    let title_flag = "All Styles"
    if(flag!=0){
        title_flag = flag;
    }
    let colorPalette = ['#3db005', '#9B59B6', '#2471A3','#138D75','#D68910','#22cab7','#FF5733'];

    let stop_code = [];
    let error_data = [];
    let error_dict = {}
    let stop_list = [... new Set(machine_data.map(d=>d['StopCode']))]
    for(let i in stop_list){
        error_dict[stop_list[i]] = machine_data.filter(d=>d['StopCode']==stop_list[i]).length;
    }
    let error_top_7 =  Object.keys(error_dict).sort(function(a,b){
        return error_dict[b]-error_dict[a];
    });
    error_top_7 = error_top_7.slice(0,7)
    error_top_7.forEach(function (d){
        error_data.push({value:error_dict[d],name:d})
    })

    if (document.getElementById('realTime_machine_error') != null) {
        echarts.dispose(document.getElementById('realTime_machine_error'))
    }
    let myChart2 = echarts.init(document.getElementById('realTime_machine_error'));
    let option2 = {
        title:{
            text:'前7故障--'+title_flag,
            textStyle:{
                color:'#e97f24'
            }
        },
        legend:{
            orient: 'vertical',
            top:'10%',
            left: "1%",
            textStyle:{
                color:'white'
            },
            data: error_top_7
        },
        tooltip: {
            trigger: 'axis',
            transitionDuration:0,

        },

        series: [
            {
                name: 'Products',
                type: 'pie',
                center: ['70%', '55%'],
                radius: ['45%', '55%'],
                avoidLabelOverlap: false,
                label: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    label: {
                        show: true,
                        fontSize: '14',
                        formatter: '{b}'+'\n'+' {c} ({d}%)'
                    },

                },
                labelLine: {
                    show: false
                },
                data: error_data,
                color: colorPalette,
            }
        ]
    };


    myChart2.clear();
    myChart2.setOption(option2);
    window.onresize = function(){
        myChart2.resize();
    }
}


function real_machine_error_chart(error_data){

    let colorPlate = [ '#3b8ade', '#f1aa1d','#DF3B45','#3db005', '#9B59B6', '#2471A3','#138D75','#D68910','#34495E','#FF5733','#00b04f'];
    let error_code = [...new Set(error_data.map(d=>d['StopCode']))];
    let data_value = []
    let error_dict = {}
    for(let i in error_code){
        let error_sublist = error_data.filter(d=>d['StopCode']==error_code[i])
        error_dict[error_code[i]] = {count:error_sublist.length,description:error_sublist[0]['description'],code:error_code[i]}
    }

    let top_10_error =  Object.keys(error_dict).sort(function(a,b){
        return error_dict[b]['count']-error_dict[a]['count'];
    });
    top_10_error = top_10_error.slice(0,10)
    top_10_error.forEach(function(d){
        data_value.push({value:error_dict[d]['count'],name:error_dict[d]['code']})
    })


    if (document.getElementById('real_machine_error_chart') != null) {
        echarts.dispose(document.getElementById('real_machine_error_chart'))
    }
    let myChart = echarts.init(document.getElementById('real_machine_error_chart'));
    let option = {

        tooltip: {
            trigger: 'item',
            showDelay: 20,
            hideDelay: 20,
            transitionDuration:0,

            formatter: function(data){
                return error_dict[data['name']]['description']+'<br/>'+'Counts：'+data.value+' ('+data.percent+'%)'
            }
        },
        legend: {
            show:false,
        },
        grid: {
            top:'2%',
            left: '0%',
            right: '14%',
            bottom: '3%'
        },

        label:{
            textStyle:{
                fontWeight : 'normal',
                fontSize : 26
            }

        },
        series: [
            {
                type: 'pie',
                radius: '50%',
                center: ['50%', '52%'],
                data: data_value,
                color:colorPlate,
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };
    myChart.clear();
    myChart.setOption(option);
    window.onresize = function(){
        myChart.resize();
    }
}