

//////////////////database summary
function database_summary(data,start_date,start_time,end_date,end_time){

    diagram_reset();

    let defects = data['defects'];
    let error = data['error'];
    let products = data['product'];


    let machine_data = machine_efficiency(products,start_date,start_time,end_date,end_time);
    let MachNum = [...new Set(products.map(item=>item['MachCode']))]
    let StyleList = [...new Set(products.map(item=>item['StyleCode']))]
    summary_chart(machine_data);
    summary_table(products,StyleList,defects);
    error_distribute(start_date,start_time,end_date,end_time,error);
    machine_efficiency_distribute(machine_data,products,error,start_date,start_time,end_date,end_time,defects);
    error_summary(error,start_date,start_time,end_date,end_time);

}

//summary chart for machine efficiency
function summary_chart(summary_data){

    if (document.getElementById('sum_chart') != null) {
        echarts.dispose(document.getElementById('sum_chart'))
    }

    let myChart = echarts.init(document.getElementById('sum_chart'));

    let colorPalette = ['#00b04f', '#3b8ade', '#f1aa1d','#DF3B45'];
    let powerOFF = []
    let machine_num = 0;
    let Total = 0;
    let pie_data = [0,0,0,0]
    for(let i in summary_data){
        if(summary_data[i]!="0.00"){
            machine_num+=1
            let obj = parseFloat(summary_data[i]);
            Total+=obj
            if(obj<80 && obj>0){
                pie_data[3]+=1;
            }else if(obj>=80 && obj<90){
                pie_data[2]+=1;
            }else if(obj>=90 && obj<95){
                pie_data[1]+=1;
            }else if(obj>=95){
                pie_data[0]+=1;
            }
        }else{
            powerOFF.push(i)
        }
    }

    let option = {

        tooltip: {
            trigger: 'item',
            transitionDuration:0,
            formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        legend: {
            itemWidth: 8,
            itemHeight: 8,
            left: 'center',
            top: "1%",
            data: ['95%~100%', '90%~95%', '80%~90%', '<80%'],
            textStyle:{
                fontSize : 12
            }
        },
        series: [
            {
                name:'生产效率',
                type: 'pie',
                radius: [30, 55],
                center: ['57%', '57%'],
                roseType: 'area',
                data: [
                    {value: pie_data[0], name: '95%~100%'},
                    {value: pie_data[1], name: '90%~95%'},
                    {value: pie_data[2], name: '80%~90%'},
                    {value: pie_data[3], name: '<80%'}
                ],
                label:{            //饼图图形上的文本标签
                    normal:{
                        show:true,
                        position:'outside', //标签的位置
                        textStyle : {
                            fontSize : 13    //文字的字体大小
                        },
                        formatter:'{c} ({d}%)'


                    }
                },
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                },
                color: colorPalette,
                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b} : {c} ({d}%)'
                },
                labelLine: {    //引导线设置
                    normal: {
                        show: true,   //引导线显示
                        length:0.001
                    }
                },
            }
        ]
    };
    myChart.clear();
    myChart.setOption(option);
    window.onresize = function() {
        myChart.resize();
    }
    let total_pieces = 0;
    let machines = 0;
    let workE =parseFloat(0.0);
    let timeE = 0;
    for(let i in summary_data){
        if(summary_data[i]['openTime']>0){
            total_pieces+=summary_data[i]['pieces']
            machines+=1;
            if (summary_data[i]['workE']){
                console.log(summary_data[i]['workE'])
                workE+=parseFloat(summary_data[i]['workE'])
            }else{
                machines-=1
            }

            timeE+=parseFloat(summary_data[i]['timeE'])
        }
    }


    document.getElementById('sum_ae').innerText='平均效率(生产效率>0.0%):'+(Total/machine_num).toFixed(2)+'%';
    document.getElementById('sum_ate').innerText='平均效率(包含生产效率 = 0.0%):'+(Total/(machine_num+powerOFF.length)).toFixed(2)+'%';
    document.getElementById('sum_mn').innerText='机器数量(生产效率 > 0.0%):'+machine_num.toString();
    document.getElementById('sum_po').innerText='机器数量 (包含生产效率 = 0.0%):'+powerOFF.toString();
}

//machine efficiency Cal
function machine_efficiency(data,start_date,start_time,end_date,end_time){
    let start = Date.parse(new Date(start_date+" "+start_time));
    let end = Date.parse(new Date(end_date+' '+end_time));
    let  usedTime = (end - start)/1000;
    let machine_id= [... new Set(data.map(item=>item['MachCode']))];
    let machine_id_efficiency = {}
    for(let i in machine_id){
        let obj = data.filter(item=>item['MachCode'] == machine_id[i])
        let totalCount = 0;
        let cycle = {}
        for(let j in obj){
            let data_item = obj[j]
            if(data_item['Cycle'] in cycle){
                cycle[data_item['Cycle']]['pieces']+=data_item['Pieces']
            }else{
                cycle[data_item['Cycle']] = {'pieces':data_item['Pieces']}
            }
        }
        let cycleFlag = 0;
        let maxNumPiece = 0;
        for(let m in cycle){
            let pieces = parseInt(cycle[m]['pieces'])
            totalCount+=pieces;
            if(pieces>maxNumPiece){
                cycleFlag = parseInt(m);
                maxNumPiece = pieces;
            }
        }

        machine_id_efficiency[machine_id[i]] = ((totalCount/(usedTime/cycleFlag))*100).toFixed(2)
    }
    return machine_id_efficiency
}

//summary table
function summary_table(data,StyleList,defects){
    let content_html = "";
    for(let i in StyleList){
        let style_data = data.filter(item=>item['StyleCode']==StyleList[i])
        let amounts = 0
        style_data.forEach(function(d){
            amounts+=d['Pieces']
        })
        let content ='<tr><td>'+StyleList[i]+'</td><td>'+(parseFloat(amounts)/2).toFixed(1)+'</td><td>'+'</td><td>'+'</td><td>'+'\n';
        content_html+=content

    }
    document.getElementById("summary_table").innerHTML =content_html;
    let table = document.getElementById('style_table');
    let cells = table.getElementsByTagName('td');

    for (let i = 0; i < cells.length; i++) {
        // Take each cell
        let cell = cells[i];
        // do something on onclick event for cell
        cell.onclick = function (e) {
            let rowId = this.parentNode.rowIndex;

            let rowsNotSelected = table.getElementsByTagName('tr');
            for (let row = 0; row < rowsNotSelected.length; row++) {
                rowsNotSelected[row].style.backgroundColor = "";
                rowsNotSelected[row].classList.remove('selected');
            }
            let rowSelected = table.getElementsByTagName('tr')[rowId];
            rowSelected.style.backgroundColor = "yellow";
            rowSelected.className += " selected";
            let select_data = data.filter(item=>item['StyleCode']==this.innerHTML);
            table_chart_machine(select_data)
            table_chart_defects(defects);
        }
    }
}

function table_chart_machine(select_data){

    let machineId = [...new Set(select_data.map(item=>item['MachCode']))];
    let amounts = []
    for(let j in machineId){
        let amount = 0;
        let machine_data = select_data.filter(item=>item['MachCode']==machineId[j])
        machine_data.forEach(function(d){
            amount+=d['Pieces']
        })
        amounts.push(amount)
    }
    let machine_dict = {}
    for(let i= 0; i< machineId.length;i++){
        machine_dict[machineId[i]] = amounts[i]
    }
    let machId_sort =  Object.keys(machine_dict).sort(function(a,b){
        return machine_dict[b]-machine_dict[a];
    });
    console.log('test')
    console.log(machine_dict)

    let new_amounts = machId_sort.map(d=>machine_dict[d])
    if (document.getElementById('sum_chart_styleCode') != null) {
        echarts.dispose(document.getElementById('sum_chart_styleCode'))
    }
    let myChart = echarts.init(document.getElementById('sum_chart_styleCode'));
    let option = {
        tooltip: {
            transitionDuration:0,
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            }
        },
        grid: {
            top:'5%',
            left: '3%',
            right: '8%',
            bottom: '3%',
            containLabel: true
        },
        yAxis: {
            type: 'value',
            name:'(pair)',
            boundaryGap: [0, 0.01]
        },
        xAxis: {
            type: 'category',
            name: '[#]',
            axisLabel :{
                interval:0,
            },
            data: machId_sort
        },
        series: [
            {
                name: '产量（双）',
                type: 'bar',
                data:new_amounts,
                color:'#8de0b3'
            }
        ]
    };


    myChart.clear();
    myChart.setOption(option);
    window.onresize = function() {
        myChart.resize();
    }
}

///defects chart
function table_chart_defects(defects){

    let qualified = 0;
    let toeHole = 0;
    let brokenNeedle = 0;
    let missingYarn = 0;
    let logoIssue = 0;
    let dirty = 0;
    let other = 0;
    let total = 0;
    let defects_number =0;
    for(let j in defects){
        let obj = defects[j];
        qualified+=parseFloat(obj['products']);
        toeHole+=parseFloat(obj['toeHole']);
        brokenNeedle+=parseFloat(obj['brokenNeedle']);
        missingYarn+=parseFloat(obj['missingYarn']);
        logoIssue+=parseFloat(obj['logoIssue']);
        dirty+=parseFloat(obj['dirty']);
        other+=parseFloat(obj['other']);
    }
    defects_number+=(other+dirty+logoIssue+missingYarn+brokenNeedle+toeHole);
    total+=(defects_number+qualified)

    let defects_data_pie = [{value:qualified,name:'Qualified'},{value:toeHole,name:'Toe Hole'},{value:brokenNeedle,name:'Broken Needle'},
        {value:missingYarn,name:'Missing Yarn'},{value:logoIssue,name:'Logo Issue'},{value:dirty,name:'Dirty'},{value:other,name:'Other'}]
    console.log(defects_data_pie)
    let colorPalette = ['#3db005', '#9B59B6', '#2471A3','#138D75','#D68910','#34495E','#FF5733'];
    if (document.getElementById('sum_chart_defects') != null) {
        echarts.dispose(document.getElementById('sum_chart_defects'))
    }
    let myChart = echarts.init(document.getElementById('sum_chart_defects'));
    let option2 = {
        title: {
            text: 'Defects:'+defects_number+'('+((defects_number/total)*100).toFixed(2)+'%)',
            subtext:'Good Pairs:'+ (total-defects_number),
            left: 'center',
            textStyle:{
                fontFamily:'Arial',
                fontSize:16
            }
        },
        tooltip: {
            trigger: 'axis',
            transitionDuration:0,

        },
        legend: {
            orient: 'vertical',
            top:'10%',
            left: "10%",
            data: ['Qualified', 'Toe Hole', 'Broken Needle', 'Missing Yarn', 'Logo Issue','Dirty', 'Other']
        },
        series: [
            {
                name: 'Products',
                type: 'pie',
                center: ['76%', '55%'],
                radius: ['45%', '55%'],
                avoidLabelOverlap: false,
                label: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    label: {
                        show: true,
                        fontSize: '14',
                        formatter: '{b}'+'\n'+' {c} ({d}%)'
                    },

                },
                labelLine: {
                    show: false
                },
                data: defects_data_pie,
                color: colorPalette,
            }
        ]
    };

    myChart.clear();
    myChart.setOption(option2);
    window.onresize = function(){
        myChart.resize();
    }

}

//clear all diagram
function diagram_reset(){
    if (document.getElementById('sum_chart') != null) {
        echarts.dispose(document.getElementById('sum_chart'))
    }

    if (document.getElementById('sum_chart_styleCode') != null) {
        echarts.dispose(document.getElementById('sum_chart_styleCode'))
    }

    if (document.getElementById('sum_chart_defects') != null) {
        echarts.dispose(document.getElementById('sum_chart_defects'))
    }
    if (document.getElementById('efficiency_distribute') != null) {
        echarts.dispose(document.getElementById('efficiency_distribute'))
    }
    if (document.getElementById('Error_time') != null) {
        echarts.dispose(document.getElementById('Error_time'))
    }
    if (document.getElementById('Error_distribute') != null) {
        echarts.dispose(document.getElementById('Error_distribute'))
    }

    if (document.getElementById('Error_count') != null) {
        echarts.dispose(document.getElementById('Error_count'))
    }

    if (document.getElementById('Error_defects') != null) {
        echarts.dispose(document.getElementById('Error_defects'))
    }
    if (document.getElementById('Error_summary_machines') != null) {
        echarts.dispose(document.getElementById('Error_summary_machines'))
    }
    if (document.getElementById('Error_summary_time') != null) {
        echarts.dispose(document.getElementById('Error_summary_time'))
    }
}