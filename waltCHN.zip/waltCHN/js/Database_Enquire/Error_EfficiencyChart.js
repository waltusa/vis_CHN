

///main error distribute chart
function error_distribute(start_date,start_time,end_date,end_time,select_data){

    let time_start = new Date(Date.parse(start_date+' '+start_time));
    let time_end = new Date(Date.parse(end_date+' '+end_time));

    for(let i =0; i<select_data.length;i++){
        let temp_start = select_data[i]['DateRec'];
        temp_start = temp_start.replace("-", "/");
        temp_start = new Date(Date.parse(temp_start));
        select_data[i]['DateRec'] = temp_start;
        let temp_end = select_data[i]['DateEndStop'];
        temp_end = temp_end.replace("-", "/");
        temp_end = new Date(Date.parse(temp_end));
        select_data[i]['DateEndStop'] = temp_end;

    }

    let time_array = []
    let result_data;
    let valueData = [];
    let total_counts = 0;
    console.log('test')
    console.log(select_data)
    if(parseInt(time_end-time_start)===43200000){
        if(start_time=='20:00:00'){
            time_array =TimeGenerate(1200);
            result_data = Generator(1200,select_data)

        }
        else{
            time_array =TimeGenerate(480);
            result_data = Generator(480,select_data)

        }

        for(let i = 0; i < 25;i++){
            total_counts+=result_data[time_array[i]].length
            valueData.push(result_data[time_array[i]].length);
        }

        shift_chart(time_array,valueData);

    }else{
        while(time_start <= time_end){
            let t = new_time_transfer(time_start)
            time_array.push(t);
            new Date(time_start.setHours( time_start.getHours() + 12))
        }
        time_array.push(new_time_transfer(time_start));
        shifts_data(time_array,select_data);
    }
}

function shifts_data(time_array,raw_data){
    let count_data = []
    for (let i = 0;  i<time_array.length-1;i++){
        let start_time = time_array[i];
        start_time = '2020-'+start_time;
        start_time = new Date(Date.parse(start_time));
        let end_time = time_array[i+1];
        end_time = '2020-'+end_time;
        end_time = new Date(Date.parse(end_time));
        let new_select = raw_data.filter(item=>item['DateRec']>=start_time && item['DateRec']<end_time)
        count_data.push(new_select.length)
    }
    shift_chart(time_array.slice(0,time_array.length-2),count_data.slice(0,count_data.length-1))
}

function shift_chart(time_array,valueData){
    if (document.getElementById('Error_distribute') != null) {
        echarts.dispose(document.getElementById('Error_distribute'))
    }
    let myChart = echarts.init(document.getElementById('Error_distribute'));
    let count = 0;
    valueData.forEach(function(d){
        count+=d;
    })
    let text = '故障发生时间表'+'(总计故障：'+count+')'

    let option = {
        title: {
            text:text ,
            x:'left',
            textStyle:{//标题内容的样式
                color:'#FF5733',

            }
        },
        tooltip: {
            show:true,
            transitionDuration:0,
            trigger: 'axis'
        },

        xAxis: {
            type: 'category',
            data: time_array,
            axisLine:{
                lineStyle:{
                    color:'#22cab7',
                    width:2,
                }
            }
        },
        yAxis: {
            type: 'value',
            splitLine: {
                lineStyle: {
                    color:['#dda587']
                }
            },
            nameTextStyle:{
                color:['#de843f']
            },
            axisLine: {
                lineStyle:{
                    color:'#de843f',
                    width:2
                },

            }
        },
        series: [{
            name: '发生次数：',
            data: valueData,
            top:'10%',
            type: 'line',
            areaStyle: {},
            markPoint: {
                data: [
                    {type: 'max', name: '最大值'}
                ]
            },
            markLine: {
                data: [
                    {type: 'average', name: '平均值'}
                ]
            },
            itemStyle: {
                normal: {
                    barBorderRadius: 2,
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                        offset: 0,
                        color: "#e92278"
                    },
                        {
                            offset: 1,
                            color: "#ec92b7"
                        }
                    ])
                }
            }
        }]
    };
    myChart.clear();
    myChart.setOption(option);
    window.onresize = function(){
        myChart.resize();
    }
}

///main efficiency distribute chart

function machine_efficiency_distribute(machine_data,raw_data,error,start_date,start_time,end_date,end_time,defects){

    let machine_id = [];
    let machine_efficiency = [];
    let time_efficiency = [];
    let color_bar_1 = '#2fb3db';
    let color_bar_2 = '#bee576';

    for(let i in machine_data){

        let efficiency_data = raw_data.filter(d=>d['MachCode']==i);
        let timeOff = 0
        let timeOn = 0;
        efficiency_data.forEach(function(d){
            timeOn+=parseInt(d['TimeOn']);
            timeOff+=parseInt(d['TimeOff'])
        })
        if(machine_data[i]!='0.00'){
            machine_id.push(i)
            time_efficiency.push(((timeOn/(timeOn+timeOff))*100).toFixed(2))
            machine_efficiency.push(machine_data[i])
        }

    }
    if (document.getElementById('efficiency_distribute') != null) {
        echarts.dispose(document.getElementById('efficiency_distribute'))
    }

    let myChart = echarts.init(document.getElementById('efficiency_distribute'));
    let text = '机器的生产效率 & 开机效率-分布'
    let option = {
        title: {
            text:text ,
            x:'left',
            textStyle:{//标题内容的样式
                color:'#FF5733',

            }
        },

        legend: {
            data: ['生产效率 (%)', '开机效率 (%)'],
            top:"10%",
            right:'10%',
            textStyle:{//图例文字的样式
                color:'white',
                fontSize:14
            }
        },
        tooltip: {
            show:true,
            transitionDuration:0,
            trigger: 'axis',
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
        },

        calculable: true,
        xAxis: [
            {
                type: 'category',
                data: machine_id,
                name:'[#]',
                axisLabel: {
                    show: true, //默认为true，设为false后下面都没有意义了
                    interval: 0 //此处关键， 设置文本标签全部显示
                },
                axisLine:{
                    lineStyle:{
                        color:'#22cab7',
                        width:2,
                    }
                }
            }
        ],
        yAxis: [
            {
                type: 'value',
                splitLine: {
                    lineStyle: {
                        color:['#de9e7a']
                    }
                },
                nameTextStyle:{
                    color:['#e3763b']
                },
                axisLine: {
                    lineStyle:{
                        color:'#e3763b',
                        width:2
                    },

                }
            }
        ],
        series: [
            {
                name: '生产效率 (%)',
                type: 'bar',
                data:machine_efficiency,

                markPoint: {
                    data: [
                        {type: 'max', name: '最大值'},
                        {type: 'min', name: '最小值'}
                    ]
                },
                markLine: {
                    data: [
                        {type: 'average', name: '平均值'}
                    ]
                },

                color: color_bar_1,
            },
            {
                name: '开机效率 (%)',
                type: 'bar',
                data:time_efficiency,

                color: color_bar_2,
            }
        ]
    };
    myChart.clear();
    myChart.setOption(option);
    window.onresize = function(){
        myChart.resize();
    }
    myChart.on('click', function (params) {

        let select_data = error.filter(item => item['MachCode'] == params.name)
        let defects_data = defects.filter(d=>d['MachineId'].substr(2)== params.name)

        machine_summary_text(raw_data.filter(d=>d['MachCode']==params.name),defects_data)
        machine_summary_error_chart(select_data);

        ///

        machine_summary_defects_chart(defects_data);
        let time_start = new Date(Date.parse(start_date+' '+start_time));
        let time_end = new Date(Date.parse(end_date+' '+end_time));

        let time_array = []
        let result_data;
        let valueData = [];
        let total_counts = 0;

        if(parseInt(time_end-time_start)===43200000){
            if(start_time=='20:00:00'){
                time_array =TimeGenerate(1200);
                result_data = Generator(1200,select_data)

            }
            else{
                time_array =TimeGenerate(480);
                result_data = Generator(480,select_data)

            }
            console.log(time_array)
            console.log(result_data)

            for(let i = 0; i < 25;i++){
                total_counts+=result_data[time_array[i]].length
                valueData.push(result_data[time_array[i]].length);
            }
            shift_chart_machineID(time_array,valueData,params.name);

        }else{
            while(time_start <= time_end){
                let t = new_time_transfer(time_start)
                time_array.push(t);
                new Date(time_start.setHours( time_start.getHours() + 12))
            }
            time_array.push(new_time_transfer(time_start));
            shifts_data_machineID(time_array,select_data,params.name);
        }

    })
}


function shifts_data_machineID(time_array,raw_data,id){
    let count_data = []
    for (let i = 0;  i<time_array.length-1;i++){
        let start_time = time_array[i];
        start_time = '2020-'+start_time;
        start_time = new Date(Date.parse(start_time));
        let end_time = time_array[i+1];
        end_time = '2020-'+end_time;
        end_time = new Date(Date.parse(end_time));
        let new_select = raw_data.filter(item=>item['DateRec']>=start_time && item['DateRec']<end_time)
        count_data.push(new_select.length)
    }
    shift_chart_machineID(time_array.slice(0,time_array.length-2),count_data.slice(0,count_data.length-1),id)
}

function shift_chart_machineID(time_array,valueData,id){

    if (document.getElementById('Error_time') != null) {
        echarts.dispose(document.getElementById('Error_time'))
    }
    let myChart = echarts.init(document.getElementById('Error_time'));
    let count = 0;
    valueData.forEach(function(d){
        count+=d;
    })
    let text = '机器 '+id+':故障分布'+'(总计：'+count+')'

    let option = {
        title: {
            text:text ,
            x:'left',
            textStyle:{//标题内容的样式
                color:'#3385ff',

            }
        },
        tooltip: {
            show:true,
            transitionDuration:0,
            trigger: 'axis'
        },

        xAxis: {
            type: 'category',
            data: time_array,
            axisLine:{
                lineStyle:{
                    color:'#22cab7',
                    width:2,
                }
            }
        },
        yAxis: {
            type: 'value',
            splitLine: {
                lineStyle: {
                    color:['#dda587']
                }
            },
            nameTextStyle:{
                color:['#2ca0de']
            },
            axisLine: {
                lineStyle:{
                    color:'#c2e0ef',
                    width:2
                },

            }
        },
        series: [{
            name: '发生次数：',
            data: valueData,
            top:'10%',
            type: 'line',
            areaStyle: {},
            markPoint: {
                data: [
                    {type: 'max', name: '最大值'}
                ]
            },
            markLine: {
                data: [
                    {type: 'average', name: '平均值'}
                ]
            },
            itemStyle: {
                normal: {
                    barBorderRadius: 2,
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                        offset: 0,
                        color: "#0f8bdd"
                    },
                        {
                            offset: 1,
                            color: "#78b6ec"
                        }
                    ])
                }
            }
        }]
    };
    myChart.clear();
    myChart.setOption(option);
    window.onresize = function(){
        myChart.resize();
    }
}


function machine_summary_text(data,defects_data){

    let id = data[0]['MachCode'];
    let style = [... new Set(data.map(d=>d['StyleCode']))];
    let amounts = 0;
    data.forEach(function (d){
        amounts+=parseInt(d['Pieces'])
    })

    let qualified = 0;
    let defects = 0;
    defects_data.forEach(function(d){
        qualified+=parseFloat(d['products'])
        defects += (parseFloat(d['brokenNeedle'])+parseFloat(d['dirty'])+parseFloat(d['logoIssue'])+parseFloat(d['missingYarn'])+parseFloat(d['other'])+parseFloat(d['toeHole']))
    })
    let total_paring = qualified+defects;
    document.getElementById('sum_machine_id').innerText = '机器号:#'+id;
    document.getElementById('sum_machine_style').innerText = '产品型号:'+style.toString();
    document.getElementById('sum_machine_amounts').innerText = '数量（双）:'+(amounts/2).toFixed(1);
    document.getElementById('sum_machine_paring').innerText = '配袜（双）:'+total_paring.toString();
    document.getElementById('sum_machine_defects').innerText = '次品（双）:'+defects.toString();
}

/////machine error distribution
function machine_summary_error_chart(data){
    let colorPlate = [ '#3b8ade', '#f1aa1d','#DF3B45','#3db005', '#9B59B6', '#2471A3','#138D75','#D68910','#34495E','#FF5733','#00b04f'];
    let error_code = [...new Set(data.map(d=>d['StopCode']))];
    let data_value = []
    let error_dict = {}
    for(let i in error_code){
        let name = error_code[i]
        let count = data.filter(d=>d['StopCode']==name)
        console.log(count)
        error_dict[name] = count[0]['description']
        data_value.push({value:count.length,name:name})
    }
    if (document.getElementById('Error_count') != null) {
        echarts.dispose(document.getElementById('Error_count'))
    }
    let myChart = echarts.init(document.getElementById('Error_count'));
    let option = {
        title: {
            text: '机器故障分布',
            left: 'center',
            textStyle:{
                color:'#29e752'
            }
        },
        tooltip: {
            trigger: 'item',
            formatter: function(data){
                return error_dict[data['name']]+'<br/>'+'Counts：'+data.value+' ('+data.percent+'%)'
            }
        },
        legend: {
            show:false,
            left: 'center',
            data: error_code
        },
        label:{
                textStyle:{
                    fontWeight : 'normal',
                    fontSize : 26
                }

        },
        series: [
            {
                type: 'pie',
                radius: '55%',
                center: ['50%', '60%'],
                data: data_value,
                color:colorPlate,
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };
    myChart.clear();
    myChart.setOption(option);
    window.onresize = function(){
        myChart.resize();
    }


}

////machine defects data
function machine_summary_defects_chart(defects){

    let qualified = 0;
    let toeHole = 0;
    let brokenNeedle = 0;
    let missingYarn = 0;
    let logoIssue = 0;
    let dirty = 0;
    let other = 0;
    let total = 0;
    let defects_number =0;
    for(let j in defects){
        let obj = defects[j];
        qualified+=parseFloat(obj['products']);
        toeHole+=parseFloat(obj['toeHole']);
        brokenNeedle+=parseFloat(obj['brokenNeedle']);
        missingYarn+=parseFloat(obj['missingYarn']);
        logoIssue+=parseFloat(obj['logoIssue']);
        dirty+=parseFloat(obj['dirty']);
        other+=parseFloat(obj['other']);
    }
    defects_number+=(other+dirty+logoIssue+missingYarn+brokenNeedle+toeHole);
    total+=(defects_number+qualified)

    let defects_data_pie = [{value:qualified,name:'Qualified'},{value:toeHole,name:'Toe Hole'},{value:brokenNeedle,name:'Broken Needle'},
        {value:missingYarn,name:'Missing Yarn'},{value:logoIssue,name:'Logo Issue'},{value:dirty,name:'Dirty'},{value:other,name:'Other'}]
    let colorPalette = ['#3db005', '#9B59B6', '#2471A3','#138D75','#D68910','#34495E','#FF5733'];
    if (document.getElementById('Error_defects') != null) {
        echarts.dispose(document.getElementById('Error_defects'))
    }
    let myChart = echarts.init(document.getElementById('Error_defects'));
    let option2 = {
        title: {
            text: '次品分布:'+defects_number+'('+((defects_number/total)*100).toFixed(2)+'%)',
            left: 'center',
            textStyle:{
                fontFamily:'Arial',
                fontSize:18,
                color:'#f87b40'
            }
        },
        tooltip: {
            trigger: 'axis',
            transitionDuration:0,

        },
        legend: {
            orient: 'vertical',
            top:'10%',
            left: "10%",
            data: ['Qualified', 'Toe Hole', 'Broken Needle', 'Missing Yarn', 'Logo Issue','Dirty', 'Other'],
            textStyle:{
                color:'white'
            }
        },
        grid: {
            top:'5%',
            left: '0%',
            right: '14%',
            bottom: '3%'
        },
        series: [
            {
                name: 'Products',
                type: 'pie',
                center: ['60%', '48%'],
                radius: ['45%', '55%'],
                avoidLabelOverlap: false,
                label: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    label: {
                        show: true,
                        fontSize: '14',
                        formatter: '{b}'+'\n'+' {c} ({d}%)'
                    },

                },
                labelLine: {
                    show: false
                },
                data: defects_data_pie,
                color: colorPalette,
            }
        ]
    };

    myChart.clear();
    myChart.setOption(option2);
    window.onresize = function(){
        myChart.resize();
    }
}