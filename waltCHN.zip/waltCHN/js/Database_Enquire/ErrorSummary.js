function error_summary(error_data,start_date,start_time,end_date,end_time){
    //add option to select box
    let error_list = [...new Set(error_data.map(d=>d['StopCode']))]
    let error_dict = {}
    for(let i in error_list){
        let obj = error_data.filter(d=>d['StopCode']==error_list[i])
        error_dict[error_list[i]] = {count:obj.length,Code:error_list[i],description:obj[0]['description'],percent:((obj.length/error_data.length)*100).toFixed(2)}
    }
    let rank_stopCode = Object.keys(error_dict).sort(function(a,b){
        return error_dict[b]['count']-error_dict[a]['count'];
    });
    let content_html = ""
    for(let j in rank_stopCode){
        let content ='<tr><td>'+(parseInt(j)+1)+'</td><td>'+rank_stopCode[j]+'</td><td>'+error_dict[rank_stopCode[j]]['description']+'</td><td>'
            +error_dict[rank_stopCode[j]]['count']+'</td><td>'+error_dict[rank_stopCode[j]]['percent']+'%'+'</td><td>'+'\n';
        content_html+=content
    }
    document.getElementById("error_summary_table").innerHTML =content_html;
    let table = document.getElementById('error_table');

    $(document).ready(function() {
        $('#error_summary_table tr').click(function() {
            let Something = $(this).children("td:nth-child(2)").text();
            let select_data = error_data.filter(d=>d['StopCode']==Something)
            error_summary_machine(select_data,start_date,start_time,end_date,end_time)
        });

    });
}

function select(){
    var table = document.getElementById('error_table');
    var cells = table.getElementsByTagName('td');

    for (var i = 0; i < cells.length; i++) {
        // Take each cell
        var cell = cells[i];
        // do something on onclick event for cell
        cell.onclick = function () {
            // Get the row id where the cell exists
            var rowId = this.parentNode.rowIndex;

            var rowsNotSelected = table.getElementsByTagName('tr');
            for (var row = 0; row < rowsNotSelected.length; row++) {
                rowsNotSelected[row].style.backgroundColor = "";
                rowsNotSelected[row].classList.remove('selected');
            }
            var rowSelected = table.getElementsByTagName('tr')[rowId];
            rowSelected.style.backgroundColor = "yellow";
            rowSelected.className += " selected";
        }
    }
}


//error summary table
function error_summary_machine(data,start_date,start_time,end_date,end_time){
    let stop = data[0]['StopCode']
    let machine_error = [...new Set(data.map(d=>d['MachCode']))]
    let machine_dict = {}
    for(let i in machine_error){
        let obj = data.filter(d=>d['MachCode']==machine_error[i])
        machine_dict[machine_error[i]] = obj.length
    }
    let rank_machine = Object.keys(machine_dict).sort(function(a,b){
        return machine_dict[b]-machine_dict[a];
    });
    let x_array = []
    let y_array = []
    for(let j=0;j<rank_machine.length;j++){
        x_array.push(rank_machine[j]);
        y_array.push(machine_dict[rank_machine[j]])
    }

    if (document.getElementById('Error_summary_machines') != null) {
        echarts.dispose(document.getElementById('Error_summary_machines'))
    }
    let myChart = echarts.init(document.getElementById('Error_summary_machines'));
    let option = {
        title:{
            text:'故障码:'+stop+' 在机器上的分布',
            left: 'center',
            textStyle:{
                color:'White'
            }
        },
        tooltip: {
            transitionDuration:0,
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            }
        },
        grid: {
            top:'12%',
            left: '3%',
            right: '8%',
            bottom: '3%',
            containLabel: true
        },
        yAxis: {
            type: 'value',
            axisLine:{
                lineStyle:{
                    color:'#de9c29',
                    width:2,
                }
            },
            boundaryGap: [0, 0.01]
        },
        xAxis: {
            type: 'category',
            name: '#',
            axisLabel :{
                interval:0,
            },
            nameTextStyle:{
                show:false,
                color:['#22cab7']
            },
            axisLine:{
                lineStyle:{
                    color:'#22cab7',
                    width:2,
                }
            },
            data: x_array
        },
        series: [
            {
                name: '发生次数：',
                type: 'bar',
                data:y_array,
                label: {
                    show: true,
                    position: 'insideTop',
                    formatter: function(params) {
                        if (params.value > 0) {
                            return params.value;
                        } else {
                            return ' ';
                        }
                    },
                },
                color:'#b557dd'
            }
        ]
    };


    myChart.clear();
    myChart.setOption(option);
    window.onresize = function() {
        myChart.resize();
    }
    myChart.on('click', function (params) {

        let select_data = data.filter(item => item['MachCode'] == params.name)
        let time_start = new Date(Date.parse(start_date+' '+start_time));
        let time_end = new Date(Date.parse(end_date+' '+end_time));

        let time_array = []
        let result_data;
        let valueData = [];
        let total_counts = 0;

        if(parseInt(time_end-time_start)===43200000){
            if(start_time=='20:00:00'){
                time_array =TimeGenerate(1200);
                result_data = Generator(1200,select_data)

            }
            else{
                time_array =TimeGenerate(480);
                result_data = Generator(480,select_data)

            }

            for(let i = 0; i < 25;i++){
                total_counts+=result_data[time_array[i]].length
                valueData.push(result_data[time_array[i]].length);
            }
            error_chart_machineID(time_array,valueData,params.name,select_data[0]['StopCode']);

        }else{
            while(time_start <= time_end){
                let t = new_time_transfer(time_start)
                time_array.push(t);
                new Date(time_start.setHours( time_start.getHours() + 12))
            }
            time_array.push(new_time_transfer(time_start));
            error_data_machineID(time_array,select_data,params.name,select_data[0]['StopCode']);
        }

    })

}

function error_data_machineID(time_array,raw_data,id,stopCode){
    let count_data = []
    for (let i = 0;  i<time_array.length-1;i++){
        let start_time = time_array[i];
        start_time = '2020-'+start_time;
        start_time = new Date(Date.parse(start_time));
        let end_time = time_array[i+1];
        end_time = '2020-'+end_time;
        end_time = new Date(Date.parse(end_time));
        let new_select = raw_data.filter(item=>item['DateRec']>=start_time && item['DateRec']<end_time)
        count_data.push(new_select.length)
    }
    error_chart_machineID(time_array.slice(0,time_array.length-2),count_data.slice(0,count_data.length-1),id,stopCode)
}

function error_chart_machineID(time_array,valueData,id,stopCode){
    console.log(time_array)
    console.log(valueData)
    console.log(id)

    if (document.getElementById('Error_summary_time') != null) {
        echarts.dispose(document.getElementById('Error_summary_time'))
    }
    let myChart = echarts.init(document.getElementById('Error_summary_time'));
    let count = 0;
    valueData.forEach(function(d){
        count+=d;
    })
    let text = '故障码-'+stopCode+'时间分布'+'：# '+id+'(Total：'+count+')'

    let option = {
        title: {
            text:text ,
            x:'center',
            textStyle:{//标题内容的样式
                color:'white',

            }
        },
        tooltip: {
            show:true,
            transitionDuration:0,
            trigger: 'axis'
        },

        xAxis: {
            type: 'category',
            data: time_array,
            axisLine:{
                lineStyle:{
                    color:'#22cab7',
                    width:2,
                }
            }
        },
        yAxis: {
            type: 'value',
            splitLine: {
                lineStyle: {
                    color:['#dda587']
                }
            },
            nameTextStyle:{
                color:['#dae729']
            },
            axisLine: {
                lineStyle:{
                    color:'#efedc2',
                    width:2
                },

            }
        },
        series: [{
            name: '发生次数：',
            data: valueData,
            top:'10%',
            type: 'line',
            areaStyle: {},
            markPoint: {
                data: [
                    {type: 'max', name: '最大值'}
                ]
            },
            markLine: {
                data: [
                    {type: 'average', name: '平均值'}
                ]
            },
            itemStyle: {
                normal: {
                    barBorderRadius: 2,
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                        offset: 0,
                        color: "#4e33e7"
                    },
                        {
                            offset: 1,
                            color: "#d8e2ac"
                        }
                    ])
                }
            }
        }]
    };
    myChart.clear();
    myChart.setOption(option);
    window.onresize = function(){
        myChart.resize();
    }
}