



///////////////////////////////////////////////////////////////////////////////////////////////////Paring
//paring data summary
function paring_qc(){
    let p_name = $("#p_name option:selected").text();
    let p_knitted_name = $('#p_time').val();
    let p_machineId = $('#p_machineId').val();
    let Toe_hole = $('#Toe_hole').val() ? $('#Toe_hole').val():0
    let Broken_needle = $('#broken_needle').val()? $('#broken_needle').val():0
    let Missing_yarn = $('#missing_yarn').val()? $('#missing_yarn').val():0
    let log_issue = $('#logo_issue').val()? $('#logo_issue').val():0
    let dirty = $('#dirty').val()? $('#dirty').val():0
    let other = $('#p_other').val()? $('#p_other').val():0
    let product = $('#product').val()? $('#product').val():0
    let p_style = $('#p_style').val();
    let p_shift = $('#p_time_shift').val();
    console.log('fdafdaf')
    console.log(p_name)
    $.ajax({
        url: 'php/paring_qc.php',
        type: 'POST',
        data:{p_name:p_name,p_knitted_name:p_knitted_name,p_machineId:p_machineId,Toe_hole:Toe_hole,
            Broken_needle:Broken_needle,Missing_yarn:Missing_yarn,log_issue:log_issue,dirty:dirty,other:other,product:product,p_item_number:p_style,p_shift:p_shift},
        success: function(data){
            let new_data = JSON.parse(data);
            console.log(new_data)
            //add record
            let content_html = "";
            let content ='<tr><td>'+new_data[0]['DateRec']+'</td><td>'+new_data[0]['Name']+'</td><td>'+new_data[0]['itemNum']+'</td><td>' +new_data[0]['MachineId'] + '</td><td>' + new_data[0]['KnittedTime']+'</td><td>'+ new_data[0]['toeHole']+'</td><td>'+ new_data[0]['brokenNeedle']+'</td><td>'+ new_data[0]['missingYarn']+'</td><td>'+new_data[0]['logoIssue']+'</td><td>'+new_data[0]['dirty']+'</td><td>'+new_data[0]['other']+'</td><td>'+new_data[0]['products']+'</td><td>'+"<button onclick = deleterow_paring(this)>Delete</button></td></tr>";
            content_html += content + '\n';
            document.getElementById("paring_table_database_body").innerHTML =content_html;
        },
        error: function(){
            alert('Error loading XML document');
        }
    });


    //reset
    $('#p_machineId').val("");
    $('#p_style').val("");
    $('#product').val("");
    $('#Toe_hole').val("");
    $('#broken_needle').val("");
    $('#missing_yarn').val("");
    $('#logo_issue').val("");
    $('#p_other').val("");
    $('#dirty').val("");

}

//paring params reset
function paring_reset(){
    var r = confirm("Warning! It's reset button not submit, still want to clear current records?");
    if(r){
        $('#p_machineId').val("");
        $('#p_style').val("");
        $('#product').val("");
        $('#Toe_hole').val("");
        $('#broken_needle').val("");
        $('#missing_yarn').val("");
        $('#logo_issue').val("");
        $('#p_other').val("");
        $('#dirty').val("");
    }

}

// delete the last record of paring
function deleterow_paring(el) {
    var r = confirm("Warning! This operation will change database!");
    if (r == true) {
        $(el).closest('tr').remove();
        $.ajax({
            url: 'php/paring_edit.php',
            type: 'POST',
            success: function (data) {
            },
            error: function () {
                alert('Error loading XML document');
            }
        });
    } else {
    }
}


///////////////////////////////////////////////////////////////////////////////////////////////////Non Skid

// Non Skid Form display: none and block
$(function() {
    //first check
    $('input:radio[name="1st_check"]').change(function() {
        if ($(this).val() == '1') {
            $("#1st_check_button").css("display", "block");
            $("#second_check").css("display", "none");
            $("#2nd_check_button").css("display", "none");
            $("#third_check").css("display", "none");
            $("#3rd_check_button").css("display", "none");

        } else {
            $("#1st_check_button").css("display", "none");
            $("#second_check").css("display", "block");
            $("#2nd_check_button").css("display", "none");
            $("#third_check").css("display", "none");
            $("#3rd_check_button").css("display", "none");
        }
    });
    //second check
    $('input:radio[name="2nd_check"]').change(function() {
        if ($(this).val() == '1') {
            $("#1st_check_button").css("display", "none");
            //$("#second_check").css("display", "none");
            $("#2nd_check_button").css("display", "block");
            $("#third_check").css("display", "none");
            $("#3rd_check_button").css("display", "none");

        } else {
            $("#1st_check_button").css("display", "none");
            // $("#second_check").css("display", "none");
            $("#2nd_check_button").css("display", "none");
            $("#third_check").css("display", "block");
            $("#3rd_check_button").css("display", "none");
        }
    });
    $('input:radio[name="3rd_check"]').change(function() {
        if ($(this).val() == '1') {

            $("#3rd_check_button").css("display", "block");

        } else {

            $("#3rd_check_button").css("display", "block");
        }
    });
});



//Get data from non skid
function insert_data(first,second,third){
    let name = $( "#operator_name option:selected" ).text();
    let knitted_time = $("#k_time").val();
    let itemNumber = $("#item_num").val();
    let machineId = $("#machineId").val();

    let weight =$("#weight").val();
    let dt = new Date();
    let current_time = dt.getFullYear()+'-'+(dt.getMonth()+1)+'-'+dt.getDate();
    let shift = $("#k_time_shift").val();


    $.ajax({
        url: 'php/previewQC.php',
        type: 'POST',
        data:{DateRec:current_time,Name:name,styleCode:itemNumber,machineId:machineId,Weight:weight,FirstCheck:first,SecondCheck:second,ThirdCheck:third,KnittedTime:knitted_time,shift:shift},
        success: function(data){
            let new_data = JSON.parse(data);
            realtimeDisplay(new_data);
        },
        error: function(){
            alert('Error loading XML document');
        }
    });

}


//Non skid form data reset
function reset(){
    $('#machineId').val("");
    $('#item_num').val("");
    $('#weight').val("");
    $('input:radio[name="1st_check"]').each(function () { $(this).attr('checked', false); });
    $('input:radio[name="2nd_check"]').each(function () { $(this).attr('checked', false); });
    $('input:radio[name="3rd_check"]').each(function () { $(this).attr('checked', false); });
    $("#1st_check_button").css("display", "none");
    $("#second_check").css("display", "none");
    $("#2nd_check_button").css("display", "none");
    $("#third_check").css("display", "none");
    $("#3rd_check_button").css("display", "none");
}

//Real time submit non skid data display
function realtimeDisplay(qc_data){
    let content_html = "";
    let content ='<tr><td>'+qc_data[0]['DateRec']+'</td><td>'+qc_data[0]['shift']+'</td><td>' +qc_data[0]['Name'] + '</td><td>' + qc_data[0]['itemNum']+'</td><td>'+ qc_data[0]['MachineId']+'</td><td>'+ qc_data[0]['Weight']+'</td><td>'+ qc_data[0]['KnittedTime']+'</td><td>'+qc_data[0]['FirstCheck']+'</td><td>'+qc_data[0]['SecondCheck']+'</td><td>'+qc_data[0]['ThirdCheck']+'</td><td>'+"<button onclick = deleterow(this)>Delete</button></td></tr>";
    content_html += content + '\n';
    document.getElementById("paring_table_database_body").innerHTML =content_html;
}

// Delete the last record of non skid
function deleterow(el) {
    var r = confirm("Warning! This operation will change database!");
    if (r == true) {
        $(el).closest('tr').remove();
        $.ajax({
            url: 'php/previewQC_edit.php',
            type: 'POST',
            success: function (data) {
            },
            error: function () {
                alert('Error loading XML document');
            }
        });
    } else {
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////Input Spinner
