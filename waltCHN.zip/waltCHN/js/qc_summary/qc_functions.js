


/////////////paring function and graph

function paring_summary(data,start,end,flag){
    let test_summary = 0
    data.forEach(function(d){
            test_summary+=(parseFloat(d['products'])+parseFloat(d['toeHole'])+parseFloat(d['brokenNeedle'])+parseFloat(d['missingYarn'])+parseFloat(d['logoIssue'])+parseFloat(d['dirty'])+parseFloat(d['other']))
        }
    )

    let staff_data = {}
    let knitted_day = [];
    let style_list = [];
    for(let i in data){
        let obj = data[i];
        knitted_day.push(obj['KnittedTime'].substr(5,))
        if(obj['Name'] in staff_data){
            staff_data[obj['Name']]['toeHole']+=parseFloat(obj['toeHole'])
            staff_data[obj['Name']]['brokenNeedle']+=parseFloat(obj['brokenNeedle'])
            staff_data[obj['Name']]['missingYarn']+=parseFloat(obj['missingYarn'])
            staff_data[obj['Name']]['logoIssue']+=parseFloat(obj['logoIssue'])
            staff_data[obj['Name']]['dirty']+=parseFloat(obj['dirty'])
            staff_data[obj['Name']]['other']+=parseFloat(obj['other'])
            staff_data[obj['Name']]['product']+=parseFloat(obj['products'])
        }else{
            staff_data[obj['Name']] = {Name:obj['Name'],toeHole:parseFloat(obj['toeHole']),brokenNeedle:parseFloat(obj['brokenNeedle']),missingYarn:parseFloat(obj['missingYarn']),
                logoIssue:parseFloat(obj['logoIssue']),dirty:parseFloat(obj['dirty']),product:parseFloat(obj['products']),other:parseFloat(obj['other'])}
        }
    }

    //add style list to paring style dropdown menu
    if(flag==1){
        $("#paring_style_menu").empty()
        let paring_style_list = data.map(item=>item['itemNum'].toUpperCase())
        style_list = [...new Set(paring_style_list)];
        $("#paring_style_menu").append('<li class="dropdown-item" ><a href="#">All Styles</a></li>');
        for(let m in style_list){
            if(style_list[m]){
                $("#paring_style_menu").append('<li class="dropdown-item"><a href="#">'+'Style: '+style_list[m]+'</a></li>');
            }
        }
    }else{
        style_list=data.map(item=>item['itemNum'])
        style_list = [...new Set(style_list)];
    }


    let knitted_date = ""
    let unique_date = [...new Set(knitted_day)];
    for(let i in unique_date){
        if(i%7==6){
            knitted_date+=("\n"+unique_date[i])
        }else{
            knitted_date+=(";"+unique_date[i])
        }
    }

    let staff_data_pie = []
    let total = 0;
    let defects = 0;
    let qualified = 0;
    let toe_hole = 0;
    let broken_needle = 0;
    let missing_yarn = 0;
    let logo_issue = 0;
    let dirty = 0;
    let other = 0;

    for(let j in staff_data){
        let staff = staff_data[j];
        let i_defects = parseFloat(staff['toeHole'])+parseFloat(staff['brokenNeedle'])+parseFloat(staff['missingYarn'])+parseFloat(staff['logoIssue'])+parseFloat(staff['dirty'])+parseFloat(staff['other'])
        total +=((parseFloat(staff['product']))+i_defects)
        staff_data_pie.push({value:((parseFloat(staff['product']))+i_defects),name:staff['Name']})
        defects+=i_defects
        qualified+=(parseFloat(staff['product']));
        toe_hole+=parseFloat(staff['toeHole'])
        broken_needle+=parseFloat(staff['brokenNeedle'])
        missing_yarn+=parseFloat(staff['missingYarn'])
        logo_issue+=parseFloat(staff['logoIssue'])
        dirty+=parseFloat(staff['dirty'])
        other+=parseFloat(staff['other'])
    }

    let defects_data_pie = [{value:qualified,name:'Qualified'},{value:toe_hole,name:'Toe Hole'},{value:broken_needle,name:'Broken Needle'},
        {value:missing_yarn,name:'Missing Yarn'},{value:logo_issue,name:'Logo Issue'},{value:dirty,name:'Dirty'},{value:other,name:'Other'}]



    if (document.getElementById('paring_chart_1') != null) {
        echarts.dispose(document.getElementById('paring_chart_1'))
    }
    let myChart = echarts.init(document.getElementById('paring_chart_1'));
    let colorPalette = ['#e58033', '#8c43e0', '#f15b7a','#6091f3','#e57008','#f36069'];
    let colorPalette2 = ['#3db005', '#9B59B6', '#2471A3','#138D75','#D68910','#34495E','#FF5733'];

    let option = {
        title: {
            text: 'Total Products(pair):'+total,
            subtext: 'Knitted:'+knitted_date,
            left: 'center',
            textStyle:{
                fontFamily:'Arial',
                fontSize:16
            }
        },
        grid: {
            left: '12%',
            right: '16%',
            bottom:'24%'
        },

        legend: {
            top:"25%",
        },
        tooltip: {
            formatter: '{b}<br/> {c} ({d}%)',
            transitionDuration:0
        },

        series: [{
            type: 'pie',
            radius: '40%',
            center: ['55%', '65%'],
            labelLine: {
              length:3
            },
            data: staff_data_pie,
            label:{            //饼图图形上的文本标签
                normal:{
                    show:true,
                    textStyle : {
                        fontSize : 12   //文字的字体大小
                    },
                    formatter:'{c}'+'\n'+'({d}%)'
                }
            },
            color: colorPalette,
            // No encode specified, by default, it is '2012'.
        }
        ]
    };
    myChart.clear();
    myChart.setOption(option);
    window.onresize = function(){
        myChart.resize();
    }

    ///////////pie chart2
    if (document.getElementById('paring_chart_2') != null) {
        echarts.dispose(document.getElementById('paring_chart_2'))
    }
    let myChart2 = echarts.init(document.getElementById('paring_chart_2'));
    let option2 = {
        title: {
            text: 'Defects:'+defects+'('+((defects/total)*100).toFixed(2)+'%)',
            subtext:'Good Pairs:'+ (total-defects),
            left: 'center',
            textStyle:{
                fontFamily:'Arial',
                fontSize:16
            }
        },
        tooltip: {
            trigger: 'axis',
            transitionDuration:0,

        },
        legend: {
            orient: 'vertical',
            top:'10%',
            left: "10%",
            data: ['Qualified', 'Toe Hole', 'Broken Needle', 'Missing Yarn', 'Logo Issue','Dirty', 'Other']
        },
        series: [
            {
                name: 'Products',
                type: 'pie',
                center: ['76%', '55%'],
                radius: ['45%', '55%'],
                avoidLabelOverlap: false,
                label: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    label: {
                        show: true,
                        fontSize: '14',
                        formatter: '{b}'+'\n'+' {c} ({d}%)'
                    },

                },
                labelLine: {
                    show: false
                },
                data: defects_data_pie,
                color: colorPalette2,
            }
        ]
    };


    myChart2.clear();
    myChart2.setOption(option2);
    window.onresize = function(){
        myChart2.resize();
    }


    ////chart 3
    console.log('test1')
    console.log(data)
    let bar_data = date_transfer(start,end,data);
    console.log('test2')
    console.log(data)
    let x= [];
    let y_amount = [];
    let y_rate = [];

    for(let i in bar_data) {
        x.push(i)
        let i_defects = 0;
        let qualified = 0;
        bar_data[i].forEach(function (d) {
            i_defects += (parseFloat(d['toeHole']) + parseFloat(d['brokenNeedle']) + parseFloat(d['missingYarn']) + parseFloat(d['logoIssue']) + parseFloat(d['dirty']) + parseFloat(d['other']))
            qualified += (parseFloat(d['products']))

        })

        y_rate.push(((qualified/(qualified+i_defects))* 100).toFixed(2))
        y_amount.push(qualified+i_defects)
    }

    if (document.getElementById('paring_chart_3') != null) {
        echarts.dispose(document.getElementById('paring_chart_3'))
    }
    let myChart3 = echarts.init(document.getElementById('paring_chart_3'));
    let option3 = {
        title:{
            text:enquire_date_flag.toUpperCase()+' Statistics',
            left:'center',
            textStyle:{
                fontFamily:'Arial',
                fontSize:16
            }

        },
        textStyle:{
            fontFamily:'Arial',
            fontSize:16
        },
        legend: {
            top:'10%',
            data: ['Good Rate(%)', 'Paring Amounts(pair)'],
            textStyle:{
                fontFamily:'Arial',
                fontSize:12
            }
        },
        tooltip: {
            trigger: 'axis',
            transitionDuration:0,

        },
        grid: {
            left: '12%',
            right: '16%',
            bottom:'24%'
        },
        xAxis: [
            {
                type: 'category',
                data: x,
                splitLine: {//显示分割线
                    show: true
                }
            }

        ],
        yAxis: [
            {
                type: 'value',
                splitLine: {//不显示分割线
                    show: false
                },
            },
            {
                splitLine: {//不显示分割线
                    show: false
                },
                type: 'value',
                min: Math.min(...y_rate),
                max: 100,
                interval: 10,
                axisLabel: {
                    formatter: '{value} %'
                }
            }

        ],
        series: [

            {
                name: 'Paring Amounts(pair)',
                type: 'bar',
                data: y_amount,
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                    offset: 0,
                    color: "#14f1be"
                },
                    {
                        offset: 1,
                        color: "#8ae5e5"
                    }
                ]),
                label: {
                    show: true,
                    position: 'Top',
                    formatter: function(params) {
                        if (params.value > 0) {
                            return params.value;
                        } else {
                            return ' ';
                        }
                    },
                },
            },
            {
                name: 'Good Rate(%)',
                type: 'line',
                yAxisIndex: 1,
                data: y_rate
            }
        ]
    };


    myChart3.clear();
    myChart3.setOption(option3);
    window.onresize = function(){
        myChart3.resize();
    }

    // chart 4
    let style_qualified = []
    let style_defects = []
    style_list = [...new Set(style_list)];
    let x_style = [];
    for(let item in style_list){
        let defects_style = 0;
        let qualified_style = 0;
        let style_data = data.filter(it=>it['itemNum']==style_list[item])
        style_data.forEach(function (d){
            defects_style+=((parseFloat(d['toeHole']) + parseFloat(d['brokenNeedle']) + parseFloat(d['missingYarn']) + parseFloat(d['logoIssue']) + parseFloat(d['dirty']) + parseFloat(d['other'])))
            qualified_style += parseFloat(d['products']);
        })
        if((qualified_style+defects_style)!=0){
            x_style.push(style_list[item])
            style_defects.push(defects_style)
            style_qualified.push(qualified_style)
        }

    }
    if (document.getElementById('paring_chart_4') != null) {
        echarts.dispose(document.getElementById('paring_chart_4'))
    }
    let myChart4 = echarts.init(document.getElementById('paring_chart_4'));
    let option4 = {
        title:{
            text:'Style Statistics',
            left:'center',
            textStyle:{
                fontFamily:'Arial',
                fontSize:16
            }
        },
        tooltip: {
            trigger: 'axis',
            showDelay: 20,
            hideDelay: 20,
            transitionDuration:0,
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
        },
        legend: {
            top:'15%',
            data: ['Qualified', 'Defects']
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '15%',
            containLabel: true
        },
        xAxis: {
            type: 'value'
        },
        yAxis: {
            type: 'category',
            data: x_style
        },
        series: [
            {
                name: 'Qualified',
                type: 'bar',
                stack: '总量',
                label: {
                    show: false
                },
                data: style_qualified,
                color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
                    offset: 0,
                    color: "#19a748"
                },
                    {
                        offset: 1,
                        color: "#93efad"
                    }
                ]),
            },
            {
                name: 'Defects',
                type: 'bar',
                stack: '总量',
                label: {
                    show: false
                },
                data: style_defects,
                color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [{
                    offset: 0,
                    color: "#db1c39"
                },
                    {
                        offset: 1,
                        color: "#ec8ea2"
                    }
                ]),
            },
        ]
    };
    myChart4.clear();
    myChart4.setOption(option4);
    window.onresize = function(){
        myChart4.resize();
    }



    //chart 5 defects distribution on machine
    let colorPalette3 = ['#9B59B6', '#2471A3','#138D75','#D68910','#34495E','#FF5733'];

    let machine_id = [... new Set(data.map(item=>item['MachineId']))]
    let defects_data = ['toeHole','brokenNeedle','missingYarn','logoIssue','dirty','other']
    let series_data = []
    for (let s in defects_data){
        let defect_reason = defects_data[s];
        let series_machine_data = machine_id.map(item=>0)
        for(let j =0; j< machine_id.length;j++){
            let select_data = data.filter(item=>item['MachineId']==machine_id[j])
            for(let da in select_data){
                series_machine_data[j]+=parseFloat(select_data[da][defect_reason])
            }
        }

        let defect_series = {
            name:defect_reason,
            type:'bar',
            stack:'总量',
            label:{
                show:false,
                position:'insideTop',
                formatter: function(params) {
                    if (params.value > 0) {
                        return params.value;
                    } else {
                        return ' ';
                    }
                },
            },
            data:series_machine_data,
            color:colorPalette3[s]
        }
        series_data.push(defect_series)
    }

    machine_id = machine_id.map(item=>'#'+item.substr(2))
    if (document.getElementById('machine_defects') != null) {
        echarts.dispose(document.getElementById('machine_defects'))
    }
    let myChart5 = echarts.init(document.getElementById('machine_defects'));
    let option5 = {
        tooltip: {
            trigger: 'axis',
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
        },
        legend: {
            data: defects_data
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        yAxis: {
            type: 'value',
            name:'pair',
            splitLine: {
                lineStyle: {
                    color:['#121bbe']
                }
            },
        },
        xAxis: {
            type: 'category',
            data: machine_id
        },
        series: series_data
    };
    myChart5.clear();
    myChart5.setOption(option5);
    window.onresize = function(){
        myChart5.resize();
    }

    //pie charts click function
    myChart.on('click', function (params){
        let click_data = staff_data[params['data']['name']];
        let single_defects = parseFloat(click_data['toeHole'])+parseFloat(click_data['brokenNeedle'])+parseFloat(click_data['missingYarn'])+parseFloat(click_data['logoIssue'])+parseFloat(click_data['dirty'])+parseFloat(click_data['other'])
        let single_qualified =  parseFloat(click_data['product']);

        let defects_data_pie = [{value:single_qualified,name:'Qualified'},{value:click_data['toeHole'],name:'Toe Hole'},{value:click_data['brokenNeedle'],name:'Broken Needle'},
            {value:click_data['missingYarn'],name:'Missing Yarn'},{value:click_data['logoIssue'],name:'Logo Issue'},{value:click_data['dirty'],name:'Dirty'},{value:click_data['other'],name:'Other'}]
        myChart2.setOption({
            title: {
                text: 'Defects(pair):'+single_defects+'('+((single_defects/(parseFloat(click_data['product']+single_defects)))*100).toFixed(2)+'%)',
                subtext:params['data']['name']+' ( Good Products: '+parseFloat(click_data['product'])+')' ,
                left: 'center',
                textStyle:{//标题内容的样式
                    color:'dodgerblue',
                },
            },
            series: [{
                data: defects_data_pie
            }]
        });

        // click change mychart 3

        let x_staff= [];
        let y_amount_staff = [];
        let y_rate_staff = [];
        for(let i in bar_data) {
            x_staff.push(i)
            let i_defects = 0;
            let qualified = 0;
            let staff_bar_data = bar_data[i].filter(item=>item['Name']==params['data']['name'])
            staff_bar_data.forEach(function (d) {
                i_defects += (parseFloat(d['toeHole']) + parseFloat(d['brokenNeedle']) + parseFloat(d['missingYarn']) + parseFloat(d['logoIssue']) + parseFloat(d['dirty']) + parseFloat(d['other']))
                qualified += parseFloat(d['products'])
            })
            y_rate_staff.push((((qualified) / (qualified+i_defects)) * 100).toFixed(2))
            y_amount_staff.push((qualified+i_defects))
        }
        myChart3.setOption({
            yAxis: [
                {
                    type: 'value',
                    name: 'Pieces',
                    splitLine: {//不显示分割线
                        show: false
                    },
                },
                {
                    splitLine: {//不显示分割线
                        show: false
                    },
                    type: 'value',
                    name: 'Good Rate(%)',
                    min: Math.min(...y_rate_staff),
                    max: 100,
                    interval: 10,
                    axisLabel: {
                        formatter: '{value} %'
                    }
                }

            ],
            series: [

                {
                    name: 'Paring Amounts',
                    type: 'bar',
                    data: y_amount_staff,
                    label: {
                        show: true,
                        position: 'Top',
                        formatter: function(params) {
                            if (params.value > 0) {
                                return params.value;
                            } else {
                                return ' ';
                            }
                        },
                    },
                },
                {
                    name: 'Good Rate(%)',
                    type: 'line',
                    yAxisIndex: 1,
                    data: y_rate_staff
                }
            ]
        });

        // click change mychart 4
        let style_qualified = []
        let style_defects = []
        let style_select_data = data.filter(item=>item['Name']==params['data']['name'])
        style_list = [...new Set(style_list)];
        let x_style = [];
        for(let item in style_list){
            let defects_style = 0;
            let qualified_style = 0;
            let style_data = style_select_data.filter(it=>it['itemNum']==style_list[item])
            style_data.forEach(function (d){
                defects_style+=((parseFloat(d['toeHole']) + parseFloat(d['brokenNeedle']) + parseFloat(d['missingYarn']) + parseFloat(d['logoIssue']) + parseFloat(d['dirty']) + parseFloat(d['other'])))
                qualified_style += parseFloat(d['products']);

            })
            if((defects_style+qualified_style)!=0){
                x_style.push(style_list[item])
                style_defects.push(defects_style)
                style_qualified.push(qualified_style)
            }

        }
        myChart4.setOption({
            yAxis: {
                type: 'category',
                data: x_style
            },
            series: [

                {
                    data: style_qualified
                },
                {
                    data: style_defects
                },
            ]
        });

    });

}


function date_transfer(start_date,end_date,data){

    let date = []
    let test_date = getNextDate(start_date,0)
    end_date = getNextDate(end_date,0)
    let i = 1;
    while(test_date <= end_date){
        date.push(test_date.substr(5,5))
        test_date = getNextDate(start_date,i);
        i+=1;
    }

    let reg;
    if(enquire_date_flag=='paring_date'){
        reg = 'DateRec';
    }else{
        reg = 'KnittedTime'
    }
    let data_date = {}
    for(let i in date){
        data_date[date[i]] = data.filter(item=>item[reg].includes(date[i]))
    }

    return data_date
}

function getNextDate(date,day) {
    let dd = new Date(date);
    dd.setDate(dd.getDate() + day);
    let y = dd.getFullYear();
    let m = dd.getMonth() + 1 < 10 ? "0" + (dd.getMonth() + 1) : dd.getMonth() + 1;
    let d = dd.getDate() < 10 ? "0" + dd.getDate() : dd.getDate();
    return y + "-" + m + "-" + d;
};




////////////////Non Skip Function and Graph
/*function non_skip_summary(data_non_skip,flag){
    let total_weight = 0;
    data_non_skip.forEach(function(d){
        total_weight+=((d['Weight'])? parseFloat(d['Weight']):0)
    })
    let pass_first = data_non_skip.filter(item=>item['FirstCheck']=='pass')
    let pass_second = data_non_skip.filter(item=>item['SecondCheck']=='pass')
    let check_third = data_non_skip.filter(item=>item['ThirdCheck']=='pass' || item['ThirdCheck']=='rework' )
    let operate_first = []
    let operate_second = []
    let operate_third = []

    //add style list to dropdown menu
    if(flag==1){
        let nonSkip_style_list = data_non_skip.map(item=>item['itemNum'].toUpperCase())
        nonSkip_style_list = [...new Set(nonSkip_style_list)]
        $("#NonSkip_style_menu").empty()
        $("#NonSkip_style_menu").append('<li class="dropdown-item" ><a href="#">All Styles</a></li>');
        for(let m in nonSkip_style_list){
            if(nonSkip_style_list[m]){
                $("#NonSkip_style_menu").append('<li class="dropdown-item"><a href="#">'+'Style: '+nonSkip_style_list[m]+'</a></li>');
            }
        }
    }



    let operator_data = data_non_skip.map(item=>item['Name'])
    operator_data = [...new Set(operator_data)]
    for(let i in operator_data){
        let obj = operator_data[i];
        let obj_first = pass_first.filter(item=>item['Name'] == obj)
        let obj_second = pass_second.filter(item=>item['Name'] == obj)
        let obj_third = check_third.filter(item=>item['Name'] == obj)
        operate_first.push((obj_first)? obj_first.length:0)
        operate_second.push((obj_second)? obj_second.length:0)
        operate_third.push((obj_third)? obj_third.length:0)
    }

    if (document.getElementById('nonSkip_chart_1') != null) {
        echarts.dispose(document.getElementById('nonSkip_chart_1'))
    }
    let myChart= echarts.init(document.getElementById('nonSkip_chart_1'));
    let option = {
        tooltip: {
            trigger: 'axis',
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
        },
        legend: {
            data: ['First Check', 'Second Check', 'Third Check']
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'value'
        },
        yAxis: {
            type: 'category',
            data: operator_data
        },
        series: [
            {
                name: 'First Check',
                type: 'bar',
                stack: '总量',
                label: {
                    show: true,
                    position: 'insideRight'
                },
                data: operate_first
            },
            {
                name: 'Second Check',
                type: 'bar',
                stack: '总量',
                label: {
                    show: true,
                    position: 'insideRight',
                    formatter: function(params) {
                        if (params.value > 0) {
                            return params.value;
                        } else {
                            return ' ';
                        }
                    },
                },
                data: operate_second,

            },
            {
                name: 'Third Check',
                type: 'bar',
                stack: '总量',
                label: {
                    show: true,
                    position: 'insideRight',
                    formatter: function(params) {
                        if (params.value > 0) {
                            return params.value;
                        } else {
                            return ' ';
                        }
                    },
                },
                data: operate_third
            }
        ]
    };
    myChart.clear();
    myChart.setOption(option);
    window.onresize = function(){
        myChart.resize();
    }
    ////QC dist chart

    if (document.getElementById('nonSkip_chart_2') != null) {
        echarts.dispose(document.getElementById('nonSkip_chart_2'))
    }
    let myChart2 = echarts.init(document.getElementById('nonSkip_chart_2'));
    let option2 = {
        title: {
            text: 'Non Skid QC (Checked Numbers: '+data_non_skip.length+')',
            subtext:'Total weights(kg): '+total_weight.toFixed(2),
            left: 'right'
        },
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        legend: {
            orient: 'vertical',
            left: 'left',
            data: ['First Check', 'Second Check', 'Third Check']
        },
        series: [
            {
                name: 'Non Skip QC',
                type: 'pie',
                radius: ['40%', '60%'],
                center: ['50%', '60%'],
                data: [
                    {value: pass_first.length, name: 'First Check'},
                    {value: pass_second.length, name: 'Second Check'},
                    {value: check_third.length, name: 'Third Check'}
                ],
                label:{            //饼图图形上的文本标签
                    normal:{
                        show:true,
                        textStyle : {
                            fontSize : 12   //文字的字体大小
                        },
                        formatter:' {c} ({d}%)'
                    }
                },
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };
    myChart2.clear();
    myChart2.setOption(option2);
    window.onresize = function(){
        myChart2.resize();
    }

    let contentRow="";
    for(let i = 0; i < data_non_skip.length; i++){
        let content ='<tr><td>'+data_non_skip[i]['DateRec']+'</td><td>' +data_non_skip[i]['Name'] + '</td><td>' + data_non_skip[i]['itemNum']+'</td><td>'+
            data_non_skip[i]['MachineId']+'</td><td>'+ data_non_skip[i]['Weight']+'</td><td>'+ data_non_skip[i]['KnittedTime']+'</td><td>'+data_non_skip[i]['FirstCheck']+'</td><td>'+data_non_skip[i]['SecondCheck']+'</td><td>'+data_non_skip[i]['ThirdCheck'];
        contentRow += content + '\n';
    }
    document.getElementById("qc_nonSkip_database_body").innerHTML =contentRow;
}
*/